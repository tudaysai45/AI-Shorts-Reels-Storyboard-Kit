# Final Presentation / PPT Guide

Recommended 8-slide presentation for a 5–7 minute project demo.

## Slide 1 — Title
**AI Shorts and Reels Script and Storyboard Kit**
- Student name, register number, department and institution
- Guide name (if applicable)
- Add one screenshot of the homepage

## Slide 2 — Problem Statement
- Short-form creators need scripts, hooks, visuals and captions.
- Planning each element separately takes time.
- Beginners may struggle with scene order and timing.

## Slide 3 — Objectives
- Generate a hook and voice-over script.
- Build a timed scene storyboard.
- Suggest captions, hashtags and calls to action.
- Offer choices for platform, duration, tone and language.

## Slide 4 — Proposed Solution / Features
Show a simple flow: Topic + Preferences → AI API → Script + Storyboard + Caption Pack.
Include a screenshot of the input form and generated output.

## Slide 5 — System Architecture
User → HTML/CSS interface → Flask backend → Prompt builder → AI API → JSON parser → Results page.
Explain that the API key is stored in `.env`, not hard-coded.

## Slide 6 — Technology Stack
- Python and Flask
- OpenAI API
- HTML, CSS and Jinja templates
- python-dotenv for environment configuration

## Slide 7 — Demonstration and Testing
Live demo:
1. Enter a topic such as “3 ways AI helps students”.
2. Select platform, duration, tone and language.
3. Generate the kit.
4. Walk through the hook, script, storyboard, caption and hashtags.
5. Show validation or missing-key error handling if appropriate.

Only show real screenshots and outputs from your own run. Do not invent test results.

## Slide 8 — Conclusion and Future Scope
- One interface creates a structured first draft for short-form video planning.
- Human review remains important before publishing.
- Future work: storyboard images, voice-over, subtitle export, project history and secure deployment.
- End with “Thank you” and invite questions.

## Presentation tips
- Keep text large and use no more than 4–5 bullets per slide.
- Use screenshots from the running project.
- Explain what is implemented versus what is planned.
- Do not expose the API key in screenshots or during the demo.
- Test the app and internet connection before presenting.
