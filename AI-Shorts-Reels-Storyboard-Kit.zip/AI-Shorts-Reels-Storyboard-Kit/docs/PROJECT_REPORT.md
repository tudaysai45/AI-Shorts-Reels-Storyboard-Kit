# Project Report: AI Shorts and Reels Script and Storyboard Kit

## 1. Abstract
The AI Shorts and Reels Script and Storyboard Kit is a web application designed to help content creators plan short-form videos efficiently. The user provides a topic, platform, duration, tone, language and target audience. The application uses a language-model API to generate a video hook, voice-over script, scene-by-scene storyboard, caption, hashtags, call to action and production tips. The system combines a Python Flask backend with a responsive HTML/CSS interface.

## 2. Introduction
Short-form video platforms encourage creators to publish concise and engaging content regularly. Planning a strong opening, script, visuals, captions and tags can take time. This project combines these planning tasks in one interface and provides a structured first draft that creators can review and customize.

## 3. Problem statement
Creators may spend considerable time turning a topic into a timed script and organizing individual scenes. Beginners may also find it difficult to plan visual transitions, on-screen text and calls to action. A single tool that creates a structured content plan can reduce the initial planning effort.

## 4. Objectives
- Generate a relevant opening hook and short-video script.
- Create a scene-by-scene storyboard with timing and camera suggestions.
- Suggest captions, hashtags and a call to action.
- Support multiple platforms, tones, audiences and languages.
- Provide a simple and responsive interface.
- Keep API credentials outside the source code.

## 5. Existing system
A creator may manually brainstorm ideas, write a script, make a storyboard and separately prepare captions. These tasks can require multiple tools and repeated editing.

## 6. Proposed system
The proposed application accepts the user's creative requirements in one form and sends them to an AI language model through a backend API call. The structured response is displayed as a content kit that can be reviewed and printed or saved as a PDF through the browser.

## 7. System modules
1. **Input module:** accepts topic, platform, duration, tone, language and audience.
2. **AI generation module:** builds instructions and requests a structured response from the API.
3. **Script module:** displays the title, hook and full voice-over.
4. **Storyboard module:** displays each scene's timing, visuals, voice-over, overlay text and camera suggestion.
5. **Social metadata module:** displays caption, hashtags and call to action.
6. **Output module:** supports browser printing and Save as PDF.

## 8. System architecture
User → Web form (HTML/CSS) → Flask route → Prompt builder → AI API → JSON response parsing → Results template → Browser display / print-to-PDF.

## 9. Software and hardware requirements
**Software:** Python 3.10+, Flask, OpenAI Python SDK, python-dotenv, modern web browser, code editor and internet access.

**Hardware:** A standard laptop or desktop capable of running Python and a modern browser. AI inference is performed by the external API service, so a dedicated GPU is not required.

## 10. Implementation
The Flask application reads configuration from environment variables, validates the topic, sends the prompt to the API, parses the response and passes it to a Jinja template. The frontend uses responsive CSS and renders each storyboard scene as a separate card. Errors are displayed to the user without exposing a full stack trace.

## 11. Testing plan
- Submit a valid topic and verify that a content kit appears.
- Submit an empty topic and verify validation feedback.
- Run without an API key and verify that setup instructions are shown.
- Test different durations, platforms, tones and languages.
- Test the layout on desktop and mobile screen sizes.
- Test browser printing / Save as PDF.
- Verify that `.env` is excluded from Git.

## 12. Expected result
The application returns a structured short-video planning kit containing a title, hook, script, storyboard scenes, caption, hashtags, call to action and production tips. Output quality depends on the topic, prompt, model and API availability.

## 13. Advantages
- Consolidates several planning steps.
- Beginner-friendly workflow.
- Customizable output based on platform and audience.
- Responsive interface.
- Keeps API credentials out of the form and tracked source files.

## 14. Limitations
- Requires internet access and an API key.
- API usage may cost money.
- It generates planning materials rather than a finished video.
- AI-generated facts, tags and creative suggestions need human review.
- This starter version has no database, accounts, rate limiting or production deployment setup.

## 15. Future scope
- Generate storyboard images for each scene.
- Add text-to-speech voice-over and subtitle files.
- Save and manage projects in a database.
- Export report and storyboard to PDF/DOCX.
- Add multilingual voice and regional content styles.
- Add authentication, moderation, rate limiting and deployment monitoring.

## 16. Conclusion
The AI Shorts and Reels Script and Storyboard Kit demonstrates how an AI API can support short-form content planning through a web application. It provides creators with a useful first draft while keeping human review and editing part of the publishing process.
